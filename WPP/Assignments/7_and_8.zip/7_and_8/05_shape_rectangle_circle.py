from abc import abstractmethod, ABC
class Shape(ABC):
    @abstractmethod
    def area(self):
        pass

    @abstractmethod
    def perimeter(self):
        pass

class Rectangle(Shape):
    def __init__(self, length, breadth):
        self.length = length
        self.breadth = breadth

    def area(self):
        return self.length * self.breadth

    def perimeter(self):
        return 2 * (self.length + self.breadth)
    
class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return 3.14 * self.radius * self.radius

    def perimeter(self):
        return 2 * 3.14 * self.radius
    
r = Rectangle(10, 20)
print("Area of rectangle:", r.area())
print("Perimeter of rectangle:", r.perimeter())

c = Circle(5)
print("Area of circle:", c.area())
print("Perimeter of circle:", c.perimeter())